package com.example.springsecurityproject.repository;

import com.example.springsecurityproject.entity.UserEntity;
import com.example.springsecurityproject.entity.UserPermissionEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.security.core.GrantedAuthority;

import javax.transaction.Transactional;
import java.util.Collection;
import java.util.List;

public interface UserPermissionRepository extends JpaRepository<UserPermissionEntity, Long> {


    @Query (nativeQuery = true, value = "SELECT t.role_name FROM role_entity AS t INNER JOIN user_permission_entity AS t2 ON t2.role_id = t.id WHERE t2.user_id = ?1")
    List<String> getUserPermissionEntity(UserEntity userEntity);
}

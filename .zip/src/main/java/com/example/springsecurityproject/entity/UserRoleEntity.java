package com.example.springsecurityproject.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class UserRoleEntity {
    /*
    USER(Sets.newHashSet()),
    ADMIN(Sets.newHashSet(BLOG_READ, BLOG_WRITE)),
    MODERATOR (Sets.newHashSet(BLOG_READ));



    private final Set<UserPermissionEntity> permissions;

    public Set<SimpleGrantedAuthority> getGrantedAuthorities(){
        Set<SimpleGrantedAuthority> permissions = getPermissions().stream()
                .map(permission -> new SimpleGrantedAuthority(permission.getPermission()))
                .collect(Collectors.toSet());

        permissions.add(new SimpleGrantedAuthority("ROLE_" + this.name()));
        return permissions;
    }

     */
}
